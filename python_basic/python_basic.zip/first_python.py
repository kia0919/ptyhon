print('안녕하세요')
print('안녕히 계세요')